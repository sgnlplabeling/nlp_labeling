package com.diquest.lltp.modules.check.dao;

import org.springframework.stereotype.Repository;

import com.diquest.lltp.common.dao.CommonDAO;

@Repository("CheckLabelingDao")
public class CheckLabelingDao extends CommonDAO {
	
}
