package com.diquest.lltp.modules.learning.service;

import com.diquest.lltp.domain.DocumentVo;

public interface LearningService {

	public void learningStart(DocumentVo vo) throws Exception;

}
