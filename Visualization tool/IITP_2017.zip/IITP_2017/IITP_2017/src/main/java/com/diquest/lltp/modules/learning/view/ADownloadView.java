/**
 * 
 */
package com.diquest.lltp.modules.learning.view;

import org.springframework.web.servlet.view.AbstractView;

/**
 * 
 * 추상화 뷰
 * 
 * @author number40
 * @date 2017. 11. 28.
 */
public abstract class ADownloadView extends AbstractView {

}
