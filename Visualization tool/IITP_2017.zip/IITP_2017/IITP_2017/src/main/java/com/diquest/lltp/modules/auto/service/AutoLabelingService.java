package com.diquest.lltp.modules.auto.service;

import com.diquest.lltp.domain.DocumentVo;

public interface AutoLabelingService {

	public void labelingStart(DocumentVo vo) throws Exception;
	
}
